<div class="entry-share">
    <script type="text/javascript">var switchTo5x=true;</script>
    <script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script>
    <script type="text/javascript">stLight.options({publisher: "07305ded-c299-419b-bbfc-2f15806f61b2", doNotHash: false, doNotCopy: false, hashAddressBar: false});</script>

    <span class="entry-share__item st_facebook_large" displayText='Facebook'></span>
    <span class="entry-share__item st_twitter_large" displayText='Tweet'></span>
    <span class="entry-share__item st_googleplus_large" displayText='Google +'></span>
    <span class="entry-share__item st_sharethis_large" displayText='ShareThis'></span>
</div>