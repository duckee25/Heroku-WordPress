<?php $stm_icons = array (
  0 => 
  array (
    'lnr lnr-home' => 'home',
  ),
  1 => 
  array (
    'lnr lnr-apartment' => 'apartment',
  ),
  2 => 
  array (
    'lnr lnr-pencil' => 'pencil',
  ),
  3 => 
  array (
    'lnr lnr-magic-wand' => 'magic-wand',
  ),
  4 => 
  array (
    'lnr lnr-drop' => 'drop',
  ),
  5 => 
  array (
    'lnr lnr-lighter' => 'lighter',
  ),
  6 => 
  array (
    'lnr lnr-poop' => 'poop',
  ),
  7 => 
  array (
    'lnr lnr-sun' => 'sun',
  ),
  8 => 
  array (
    'lnr lnr-moon' => 'moon',
  ),
  9 => 
  array (
    'lnr lnr-cloud' => 'cloud',
  ),
  10 => 
  array (
    'lnr lnr-cloud-upload' => 'cloud-upload',
  ),
  11 => 
  array (
    'lnr lnr-cloud-download' => 'cloud-download',
  ),
  12 => 
  array (
    'lnr lnr-cloud-sync' => 'cloud-sync',
  ),
  13 => 
  array (
    'lnr lnr-cloud-check' => 'cloud-check',
  ),
  14 => 
  array (
    'lnr lnr-database' => 'database',
  ),
  15 => 
  array (
    'lnr lnr-lock' => 'lock',
  ),
  16 => 
  array (
    'lnr lnr-cog' => 'cog',
  ),
  17 => 
  array (
    'lnr lnr-trash' => 'trash',
  ),
  18 => 
  array (
    'lnr lnr-dice' => 'dice',
  ),
  19 => 
  array (
    'lnr lnr-heart' => 'heart',
  ),
  20 => 
  array (
    'lnr lnr-star' => 'star',
  ),
  21 => 
  array (
    'lnr lnr-star-half' => 'star-half',
  ),
  22 => 
  array (
    'lnr lnr-star-empty' => 'star-empty',
  ),
  23 => 
  array (
    'lnr lnr-flag' => 'flag',
  ),
  24 => 
  array (
    'lnr lnr-envelope' => 'envelope',
  ),
  25 => 
  array (
    'lnr lnr-paperclip' => 'paperclip',
  ),
  26 => 
  array (
    'lnr lnr-inbox' => 'inbox',
  ),
  27 => 
  array (
    'lnr lnr-eye' => 'eye',
  ),
  28 => 
  array (
    'lnr lnr-printer' => 'printer',
  ),
  29 => 
  array (
    'lnr lnr-file-empty' => 'file-empty',
  ),
  30 => 
  array (
    'lnr lnr-file-add' => 'file-add',
  ),
  31 => 
  array (
    'lnr lnr-enter' => 'enter',
  ),
  32 => 
  array (
    'lnr lnr-exit' => 'exit',
  ),
  33 => 
  array (
    'lnr lnr-graduation-hat' => 'graduation-hat',
  ),
  34 => 
  array (
    'lnr lnr-license' => 'license',
  ),
  35 => 
  array (
    'lnr lnr-music-note' => 'music-note',
  ),
  36 => 
  array (
    'lnr lnr-film-play' => 'film-play',
  ),
  37 => 
  array (
    'lnr lnr-camera-video' => 'camera-video',
  ),
  38 => 
  array (
    'lnr lnr-camera' => 'camera',
  ),
  39 => 
  array (
    'lnr lnr-picture' => 'picture',
  ),
  40 => 
  array (
    'lnr lnr-book' => 'book',
  ),
  41 => 
  array (
    'lnr lnr-bookmark' => 'bookmark',
  ),
  42 => 
  array (
    'lnr lnr-user' => 'user',
  ),
  43 => 
  array (
    'lnr lnr-users' => 'users',
  ),
  44 => 
  array (
    'lnr lnr-shirt' => 'shirt',
  ),
  45 => 
  array (
    'lnr lnr-store' => 'store',
  ),
  46 => 
  array (
    'lnr lnr-cart' => 'cart',
  ),
  47 => 
  array (
    'lnr lnr-tag' => 'tag',
  ),
  48 => 
  array (
    'lnr lnr-phone-handset' => 'phone-handset',
  ),
  49 => 
  array (
    'lnr lnr-phone' => 'phone',
  ),
  50 => 
  array (
    'lnr lnr-pushpin' => 'pushpin',
  ),
  51 => 
  array (
    'lnr lnr-map-marker' => 'map-marker',
  ),
  52 => 
  array (
    'lnr lnr-map' => 'map',
  ),
  53 => 
  array (
    'lnr lnr-location' => 'location',
  ),
  54 => 
  array (
    'lnr lnr-calendar-full' => 'calendar-full',
  ),
  55 => 
  array (
    'lnr lnr-keyboard' => 'keyboard',
  ),
  56 => 
  array (
    'lnr lnr-spell-check' => 'spell-check',
  ),
  57 => 
  array (
    'lnr lnr-screen' => 'screen',
  ),
  58 => 
  array (
    'lnr lnr-smartphone' => 'smartphone',
  ),
  59 => 
  array (
    'lnr lnr-tablet' => 'tablet',
  ),
  60 => 
  array (
    'lnr lnr-laptop' => 'laptop',
  ),
  61 => 
  array (
    'lnr lnr-laptop-phone' => 'laptop-phone',
  ),
  62 => 
  array (
    'lnr lnr-power-switch' => 'power-switch',
  ),
  63 => 
  array (
    'lnr lnr-bubble' => 'bubble',
  ),
  64 => 
  array (
    'lnr lnr-heart-pulse' => 'heart-pulse',
  ),
  65 => 
  array (
    'lnr lnr-construction' => 'construction',
  ),
  66 => 
  array (
    'lnr lnr-pie-chart' => 'pie-chart',
  ),
  67 => 
  array (
    'lnr lnr-chart-bars' => 'chart-bars',
  ),
  68 => 
  array (
    'lnr lnr-gift' => 'gift',
  ),
  69 => 
  array (
    'lnr lnr-diamond' => 'diamond',
  ),
  70 => 
  array (
    'lnr lnr-linearicons' => 'linearicons',
  ),
  71 => 
  array (
    'lnr lnr-dinner' => 'dinner',
  ),
  72 => 
  array (
    'lnr lnr-coffee-cup' => 'coffee-cup',
  ),
  73 => 
  array (
    'lnr lnr-leaf' => 'leaf',
  ),
  74 => 
  array (
    'lnr lnr-paw' => 'paw',
  ),
  75 => 
  array (
    'lnr lnr-rocket' => 'rocket',
  ),
  76 => 
  array (
    'lnr lnr-briefcase' => 'briefcase',
  ),
  77 => 
  array (
    'lnr lnr-bus' => 'bus',
  ),
  78 => 
  array (
    'lnr lnr-car' => 'car',
  ),
  79 => 
  array (
    'lnr lnr-train' => 'train',
  ),
  80 => 
  array (
    'lnr lnr-bicycle' => 'bicycle',
  ),
  81 => 
  array (
    'lnr lnr-wheelchair' => 'wheelchair',
  ),
  82 => 
  array (
    'lnr lnr-select' => 'select',
  ),
  83 => 
  array (
    'lnr lnr-earth' => 'earth',
  ),
  84 => 
  array (
    'lnr lnr-smile' => 'smile',
  ),
  85 => 
  array (
    'lnr lnr-sad' => 'sad',
  ),
  86 => 
  array (
    'lnr lnr-neutral' => 'neutral',
  ),
  87 => 
  array (
    'lnr lnr-mustache' => 'mustache',
  ),
  88 => 
  array (
    'lnr lnr-alarm' => 'alarm',
  ),
  89 => 
  array (
    'lnr lnr-bullhorn' => 'bullhorn',
  ),
  90 => 
  array (
    'lnr lnr-volume-high' => 'volume-high',
  ),
  91 => 
  array (
    'lnr lnr-volume-medium' => 'volume-medium',
  ),
  92 => 
  array (
    'lnr lnr-volume-low' => 'volume-low',
  ),
  93 => 
  array (
    'lnr lnr-volume' => 'volume',
  ),
  94 => 
  array (
    'lnr lnr-mic' => 'mic',
  ),
  95 => 
  array (
    'lnr lnr-hourglass' => 'hourglass',
  ),
  96 => 
  array (
    'lnr lnr-undo' => 'undo',
  ),
  97 => 
  array (
    'lnr lnr-redo' => 'redo',
  ),
  98 => 
  array (
    'lnr lnr-sync' => 'sync',
  ),
  99 => 
  array (
    'lnr lnr-history' => 'history',
  ),
  100 => 
  array (
    'lnr lnr-clock' => 'clock',
  ),
  101 => 
  array (
    'lnr lnr-download' => 'download',
  ),
  102 => 
  array (
    'lnr lnr-upload' => 'upload',
  ),
  103 => 
  array (
    'lnr lnr-enter-down' => 'enter-down',
  ),
  104 => 
  array (
    'lnr lnr-exit-up' => 'exit-up',
  ),
  105 => 
  array (
    'lnr lnr-bug' => 'bug',
  ),
  106 => 
  array (
    'lnr lnr-code' => 'code',
  ),
  107 => 
  array (
    'lnr lnr-link' => 'link',
  ),
  108 => 
  array (
    'lnr lnr-unlink' => 'unlink',
  ),
  109 => 
  array (
    'lnr lnr-thumbs-up' => 'thumbs-up',
  ),
  110 => 
  array (
    'lnr lnr-thumbs-down' => 'thumbs-down',
  ),
  111 => 
  array (
    'lnr lnr-magnifier' => 'magnifier',
  ),
  112 => 
  array (
    'lnr lnr-cross' => 'cross',
  ),
  113 => 
  array (
    'lnr lnr-menu' => 'menu',
  ),
  114 => 
  array (
    'lnr lnr-list' => 'list',
  ),
  115 => 
  array (
    'lnr lnr-chevron-up' => 'chevron-up',
  ),
  116 => 
  array (
    'lnr lnr-chevron-down' => 'chevron-down',
  ),
  117 => 
  array (
    'lnr lnr-chevron-left' => 'chevron-left',
  ),
  118 => 
  array (
    'lnr lnr-chevron-right' => 'chevron-right',
  ),
  119 => 
  array (
    'lnr lnr-arrow-up' => 'arrow-up',
  ),
  120 => 
  array (
    'lnr lnr-arrow-down' => 'arrow-down',
  ),
  121 => 
  array (
    'lnr lnr-arrow-left' => 'arrow-left',
  ),
  122 => 
  array (
    'lnr lnr-arrow-right' => 'arrow-right',
  ),
  123 => 
  array (
    'lnr lnr-move' => 'move',
  ),
  124 => 
  array (
    'lnr lnr-warning' => 'warning',
  ),
  125 => 
  array (
    'lnr lnr-question-circle' => 'question-circle',
  ),
  126 => 
  array (
    'lnr lnr-menu-circle' => 'menu-circle',
  ),
  127 => 
  array (
    'lnr lnr-checkmark-circle' => 'checkmark-circle',
  ),
  128 => 
  array (
    'lnr lnr-cross-circle' => 'cross-circle',
  ),
  129 => 
  array (
    'lnr lnr-plus-circle' => 'plus-circle',
  ),
  130 => 
  array (
    'lnr lnr-circle-minus' => 'circle-minus',
  ),
  131 => 
  array (
    'lnr lnr-arrow-up-circle' => 'arrow-up-circle',
  ),
  132 => 
  array (
    'lnr lnr-arrow-down-circle' => 'arrow-down-circle',
  ),
  133 => 
  array (
    'lnr lnr-arrow-left-circle' => 'arrow-left-circle',
  ),
  134 => 
  array (
    'lnr lnr-arrow-right-circle' => 'arrow-right-circle',
  ),
  135 => 
  array (
    'lnr lnr-chevron-up-circle' => 'chevron-up-circle',
  ),
  136 => 
  array (
    'lnr lnr-chevron-down-circle' => 'chevron-down-circle',
  ),
  137 => 
  array (
    'lnr lnr-chevron-left-circle' => 'chevron-left-circle',
  ),
  138 => 
  array (
    'lnr lnr-chevron-right-circle' => 'chevron-right-circle',
  ),
  139 => 
  array (
    'lnr lnr-crop' => 'crop',
  ),
  140 => 
  array (
    'lnr lnr-frame-expand' => 'frame-expand',
  ),
  141 => 
  array (
    'lnr lnr-frame-contract' => 'frame-contract',
  ),
  142 => 
  array (
    'lnr lnr-layers' => 'layers',
  ),
  143 => 
  array (
    'lnr lnr-funnel' => 'funnel',
  ),
  144 => 
  array (
    'lnr lnr-text-format' => 'text-format',
  ),
  145 => 
  array (
    'lnr lnr-text-format-remove' => 'text-format-remove',
  ),
  146 => 
  array (
    'lnr lnr-text-size' => 'text-size',
  ),
  147 => 
  array (
    'lnr lnr-bold' => 'bold',
  ),
  148 => 
  array (
    'lnr lnr-italic' => 'italic',
  ),
  149 => 
  array (
    'lnr lnr-underline' => 'underline',
  ),
  150 => 
  array (
    'lnr lnr-strikethrough' => 'strikethrough',
  ),
  151 => 
  array (
    'lnr lnr-highlight' => 'highlight',
  ),
  152 => 
  array (
    'lnr lnr-text-align-left' => 'text-align-left',
  ),
  153 => 
  array (
    'lnr lnr-text-align-center' => 'text-align-center',
  ),
  154 => 
  array (
    'lnr lnr-text-align-right' => 'text-align-right',
  ),
  155 => 
  array (
    'lnr lnr-text-align-justify' => 'text-align-justify',
  ),
  156 => 
  array (
    'lnr lnr-line-spacing' => 'line-spacing',
  ),
  157 => 
  array (
    'lnr lnr-indent-increase' => 'indent-increase',
  ),
  158 => 
  array (
    'lnr lnr-indent-decrease' => 'indent-decrease',
  ),
  159 => 
  array (
    'lnr lnr-pilcrow' => 'pilcrow',
  ),
  160 => 
  array (
    'lnr lnr-direction-ltr' => 'direction-ltr',
  ),
  161 => 
  array (
    'lnr lnr-direction-rtl' => 'direction-rtl',
  ),
  162 => 
  array (
    'lnr lnr-page-break' => 'page-break',
  ),
  163 => 
  array (
    'lnr lnr-sort-alpha-asc' => 'sort-alpha-asc',
  ),
  164 => 
  array (
    'lnr lnr-sort-amount-asc' => 'sort-amount-asc',
  ),
  165 => 
  array (
    'lnr lnr-hand' => 'hand',
  ),
  166 => 
  array (
    'lnr lnr-pointer-up' => 'pointer-up',
  ),
  167 => 
  array (
    'lnr lnr-pointer-right' => 'pointer-right',
  ),
  168 => 
  array (
    'lnr lnr-pointer-down' => 'pointer-down',
  ),
  169 => 
  array (
    'lnr lnr-pointer-left' => 'pointer-left',
  ),
);