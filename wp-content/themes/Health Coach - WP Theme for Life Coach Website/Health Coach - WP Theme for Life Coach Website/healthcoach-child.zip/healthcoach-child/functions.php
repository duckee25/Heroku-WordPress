<?php
add_action( 'wp_enqueue_scripts', 'stm_enqueue_styles' );
function stm_enqueue_styles() {
    $deps = array('stm-bootstrap', 'stm-font-awesome', 'stm-linearicons', 'stm-hc-icons', 'stm-select2', 'stm-slick', 'stm-slick-theme', 'stm-woocommerce', 'stm-vc');
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css', $deps );
}

function stm_child_theme_setup() {
    load_child_theme_textdomain( 'healthcoach-child', get_stylesheet_directory() . '/languages' );
}
add_action( 'after_setup_theme', 'stm_child_theme_setup' );